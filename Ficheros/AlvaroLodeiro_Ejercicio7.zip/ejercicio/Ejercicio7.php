<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>

    <form class="" action="controler.php" method="post" enctype="multipart/form-data">

      <input type="file" name="archivo[]" id="archivo" multiple />
      <input type="submit" value="Subir fichero" />

    </form>

  </body>
</html>
