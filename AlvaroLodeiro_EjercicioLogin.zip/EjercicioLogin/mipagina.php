<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="style.css">
    <title></title>
  </head>
  <body class="correcto">
    <h1>Su login ha sido correcto:</h1>
    <p>Enhorabuena</p>
    <a href="home.php">Volver al login</a>

  </body>
</html>
