<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="style.css">
    <title></title>
  </head>
  <body>
    <form class="" action="proceso.php" method="post">
      <label for="">Usuario: <input class="primero" type="text" name="Usuario" value="" ></label>
      <label for="">Contraseña: <input type="password" name="Contraseña" value=""> </label>
      <input type="submit" name="Enviar" value="Enviar">
    </form>

  </body>
</html>
